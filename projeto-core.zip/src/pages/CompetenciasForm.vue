<template>
  <h3 align="center">Em Construção...</h3>
</template>

<script>
export default {
  name: 'CompetenciasForm'
}
</script>
