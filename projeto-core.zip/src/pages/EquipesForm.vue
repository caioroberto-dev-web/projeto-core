<template>
  <q-page padding class="equipes-container">
    <div v-if="equipesLista == ''">
      <h6 align="center">Carregando...</h6>
    </div>
    <div v-else>
      <h6 align="center">Equipes</h6>
      <table>
        <thead>
          <th align="start">Nome</th>
          <th align="start">Ações</th>
        </thead>
        <tbody>
          <tr v-for="equipe in equipesLista" :key="equipe.id">
            <td>{{equipe.nome}} </td>
            <td class="linha-vertical"><q-btn icon="visibility"
              color="primary"
              dense size="sm"
              @click="handlePerfilDetalhes(equipe.id)"
              ></q-btn>
              <q-btn icon="edit"
               color="primary"
               dense size="sm"
               :to="name = 'perfilDetalhes/'+ equipe.id "></q-btn>
               <q-btn
               icon="delete"
               color="negative"
               dense
               size="sm"
               @click="handleDelete(equipe.id)"
              /></td>
          </tr>
          <q-dialog v-model="basic" transition-show="rotate" transition-hide="rotate">
            <q-layout class="card-detalhes">
              <q-card-section>
                <h6 align="center">Visualização do Profissional</h6>
              </q-card-section>
              <div class="card-section row">
                <div class="col-12">
                  <p class="sub-title">Informações Pessoais</p>
                </div>
                <div class="col-md-6 col-xs-6 col-12">
                  <p>Nome: {{ perfil.nome }}</p>
                  <p>Data de nascimento: {{ perfil.dataNascimento }}</p>
                  <p>Gênero: {{ perfil.genero }}</p>
                  <p>Cidade: {{ perfil.cidade }}</p>
                  <p>Estado: {{ perfil.estado }}</p>
                  <p>País: {{ perfil.pais }}</p>
                </div>
                <div class="col-md-6 col-xs-6 col-12">
                  <p>Sobrenome: {{ perfil.sobreNome}}</p>
                  <p>Curso: Engenharia de Software</p>
                  <p>Formação: Bacharelado</p>
                  <p>Status da formação: Concluído</p>
                </div>
                <div class="col-md-6 col-xs-6 col-12 q-mt-md">
                  <p>Equipe: xxxx</p>
                  <p>Cargo: xxxx</p>
                </div>
                <div class="col-12">
                  <div class="col-12">
                    <p class="sub-title">Informações de Competências</p>
                  </div>
                  <p>Tipo de Competência</p>
                </div>
              </div>
              <q-card-actions align="right">
                <q-btn label="Sair" color="primary" v-close-popup />
              </q-card-actions>
            </q-layout>
          </q-dialog>
        </tbody>
      </table>
    </div>
  </q-page>
</template>

<script setup>
import { api } from 'src/boot/axios'
import { onMounted, ref } from 'vue'
import { useQuasar } from 'quasar'
import postService from 'src/services/posts'

defineOptions({
  name: 'EquipesForm',
  data () {
    onMounted(() => {
      getEquipes()
    })
    const equipesLista = ref([])
    const perfil = ref([])
    const $q = useQuasar()
    const { getById } = postService()
    const getEquipes = async () => {
      const res = await api.get(
        'https://661c1c06e7b95ad7fa69b6e1.mockapi.io/pessoas'
      )
      equipesLista.value = res.data
    }
    const handleDelete = async (id) => {
      try {
        $q.dialog({
          title: 'Alerta!',
          message: 'Deseja deletar este item?',
          cancel: true,
          persistent: true
        }).onOk(async () => {
          const res = await api.delete(
            'https://661c1c06e7b95ad7fa69b6e1.mockapi.io/pessoas/' + id
          )
          console.log(res)
          await getEquipes()
          $q.notify({
            message: 'Excluido com sucesso!',
            color: 'green',
            icon: 'check'
          })
        })
      } catch (error) {
        console.error(error)
        $q.notify({
          message: 'Houve um erro ao realizar a requisição no servidor!',
          color: 'red'
        })
      }
    }
    const handlePerfilDetalhes = async (id) => {
      getPerfil(id)
      this.basic = true
    }
    const getPerfil = async (id) => {
      try {
        const response = await getById(id)
        perfil.value = response
      } catch (error) {
        console.error(error)
      }
    }
    return {
      equipesLista,
      handleDelete,
      basic: ref(false),
      perfil,
      handlePerfilDetalhes
    }
  }
})
</script>

<style scoped>

table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0 15px;
}

table td {
  width: 500px;
  padding: 10px;
  text-align: left;
  vertical-align: middle;
  background-color: #d9d9d9;
  border-start-start-radius: 20px;
  border-bottom-left-radius: 20px;
}

table td:last-child {
  width: 200px;
  text-align: end;
  background-color: #d9d9d9;
  border-end-end-radius: 20px;
  border-top-right-radius: 20px;
  border-start-start-radius: 0px;
  border-bottom-left-radius: 0px;
}

.linha-vertical {
  border-left: 2px solid #1976D2;
}

.q-btn {
  margin-right: 30px;
}

.card-detalhes {
  background-color: #f6f6f6;
}

.card-section {
  width: 500px;
  padding: 15px;
  margin: 15px;
  border: 1px solid #1976D2;
  border-radius: 10px;
}

.sub-title {
  position: relative;
  font-weight: 600;
}

@media  (max-width: 768px) {
  table td {
    width: 100px;
  }

  table td:last-child {
    width: 100px;
  }

  .q-btn {
    margin-right: 30px;
  }
}
@media  (min-width: 992px) {
  table td {
    width: 800px;
  }

  table td:last-child {
    width: 300px;
  }

  .q-btn {
    margin-right: 30px;
  }
}

</style>
