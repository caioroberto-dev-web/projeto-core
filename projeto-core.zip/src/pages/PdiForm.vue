<template>
  <q-page padding>
    <h4 align="center">Em Construção...</h4>
  </q-page>
</template>

<script>
export default {
  name: 'PdiForm'
}
</script>
