<template>
  <q-page padding>
    <h6 align="center">Em Construção...</h6>
  </q-page>
</template>

<script>
export default {
  name: 'PdiForm'
}
</script>
